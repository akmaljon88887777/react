// export const add_task = (payload) => {
//   return {
//     type: 'ADD_TASK',
//     payload,
//   };
// };
// export const delete_task = (payload) => {
//   return {
//     type: 'DELETE_TASK',
//     payload,
//   };
// };

export const addUser = (payload) => {
  return {
    type: 'ADD_USER',
    payload,
  };
};


export const deleteUser = (payload) => {
  return {
    type: 'DELETE_USER',
    payload,
  };
};
