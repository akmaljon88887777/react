// // reducers.js

// const initialState = {
//   todos: [],
// };

// const todoReducer = (state = initialState, actions) => {
//   switch (actions.type) {
//     case 'ADD_TASK':
//       return {
//         ...state,
//         todos: [...state.todos, actions.payload],
//       };
//     case 'DELETE_TASK':
//       return {
//         ...state,
//         todos: state.todos.filter((i) => i.id !== actions.payload),
//       };
//     default:
//       return state;
//   }
// };

// export default todoReducer;

const initialState = {
  todos: [],
};

const todosReducer = (state = initialState, actions) => {
  switch (actions.type) {
    case 'ADD_USER':
      return {
        ...state,
        todos: [...state.todos, actions.payload],
      };
    case 'DELETE_USER':
      return {
        ...state,
        todos: state.todos.filter((i) => i.id !== actions.payload),
      };

    default:
      return state;
  }
};

export default todosReducer;
