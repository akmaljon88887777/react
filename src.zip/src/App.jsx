// App.js
import React from 'react';
import Todo from './component/Todo/index';

const App = () => (
    <div>
        <Todo />
    </div>
);

export default App;
