import { BiAddToQueue } from "react-icons/bi"; 
import { BsTrash } from "react-icons/bs"; 
import { AiFillEdit } from "react-icons/ai"; 
// import React, { useState } from 'react'
// import { useDispatch, useSelector } from 'react-redux'
// import { delete_task, add_task } from '../../redux/actions'

// const Todo = () => {
//     const [newItem, setNewItem] = useState('')
//     const dispatch = useDispatch()
//     const todos = useSelector(state => state.todoReducer.todos)
//     function addItem() {

//         const item = {
//             id: Math.trunc(Math.random(1000) * 1000),
//             value: newItem
//         }
//         dispatch(add_task(item))
//         setNewItem('')
//     }

//     function handleDete(id) {
//         dispatch(delete_task(id))
//     }
//     return (
//         <div>
//             <input
//                 type="text"
//                 placeholder='Add item...'
//                 value={newItem}
//                 onChange={(e) => setNewItem(e.target.value)}
//             />
//             <button onClick={() => addItem()}>Add</button>
//             <ul>
//                 {todos.map((item) => {
//                     return (
//                         <li key={item.id}>{item.id} - {item.value}
//                             <button onClick={() =>
//                                 handleDete(item.id)}>❌</button>
//                         </li>
//                     )
//                 })}
//             </ul>
//         </div>
//     )
// }

// export default Todo

import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { addUser, deleteUser } from './../../redux/actions';

const Todo = () => {

    const [values, setValues] = useState('')

    const dispatch = useDispatch()
    const todos = useSelector(state => state.todoReducer.todos)

    const handleAdd = () => {
        const item = {
            id: Math.trunc(Math.random(1000) * 1000),
            value: values
        }
        dispatch(addUser(item))
        setValues('')
    }


    const handleDelete = (id) => {
        dispatch(deleteUser(id))
    }
    const handleEdit = () => {

    }
    return (
        <div className='justify-center grid gap-2'>
            {/* 1 */}
            <h1 className='text-center'>Hello Redux</h1>
            {/* 2 */}
            <div className='flex justify-center gap-2'>
            <input className='border border-gray-600 rounded pl-2' type="text"
                placeholder='Enter user...'
                value={values}
                onChange={(e) => setValues(e.target.value)}
            />
            <button className='border border-gray-500 p-2 rounded' onClick={() => handleAdd()}><BiAddToQueue color="blue" size={20}/></button>
            </div>
            {/* 3 */}
            <ul>

                {todos?.map((item) => {
                    return (
                        <div className='flex justify-between w-full h-10 p-2 my-2 gap-2 bg-green-400 rounded' key={item.id}>
                            <li> {item.id} - {item.value}</li>
                            <div className="flex justify-end">
                              <button onClick={() => handleEdit()} className=' p-2 rounded flex justify-end items-center'><AiFillEdit color="orange" size={21}/></button>
                              <button onClick={() => handleDelete(item.id)} className="active:contents:'salom'"><BsTrash size={20} color="red"/></button>
                            </div>
                        </div>
                    )
                })}
            </ul>
        </div>
    )
}

export default Todo